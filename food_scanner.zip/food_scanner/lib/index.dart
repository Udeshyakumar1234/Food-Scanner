// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/settings/settings_widget.dart' show SettingsWidget;
export '/pages/favorites/favorites_widget.dart' show FavoritesWidget;
export '/pages/meals/meal_details/meal_details_widget.dart'
    show MealDetailsWidget;

import 'package:sqflite/sqflite.dart';

/// BEGIN ADDTODATABASE
Future performAddToDataBase(
  Database database, {
  String? id,
  String? name,
  String? grade,
  int? calories,
}) {
  final query = '''
INSERT INTO Food (id, name, grade, calories)
VALUES ('${id}', '${name}', '${grade}', ${calories});
''';
  return database.rawQuery(query);
}

/// END ADDTODATABASE

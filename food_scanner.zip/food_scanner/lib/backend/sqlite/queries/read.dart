import '/backend/sqlite/queries/sqlite_row.dart';
import 'package:sqflite/sqflite.dart';

Future<List<T>> _readQuery<T>(
  Database database,
  String query,
  T Function(Map<String, dynamic>) create,
) =>
    database.rawQuery(query).then((r) => r.map((e) => create(e)).toList());

/// BEGIN GETALL
Future<List<GetAllRow>> performGetAll(
  Database database,
) {
  final query = '''
select * from Food;

''';
  return _readQuery(database, query, (d) => GetAllRow(d));
}

class GetAllRow extends SqliteRow {
  GetAllRow(Map<String, dynamic> data) : super(data);

  String get id => data['id'] as String;
  String? get name => data['Name'] as String?;
  String? get grade => data['grade'] as String?;
  int? get calories => data['Calories'] as int?;
}

/// END GETALL

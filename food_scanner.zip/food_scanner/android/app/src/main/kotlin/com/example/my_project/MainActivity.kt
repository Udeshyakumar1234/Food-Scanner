package com.mycompany.foodscanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
